const mongoose = require('mongoose')

const jobSchema = mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    type:{
        type:String,
        required:true
    }
},{timestamps:true})

const job = mongoose.model('job',jobSchema)
module.exports=job