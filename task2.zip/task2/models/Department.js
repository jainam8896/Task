const mongoose = require('mongoose')

const DepartmentSchema = mongoose.Schema({
    name:{
        type:String,
        required: true
    },
    isActive:{
        type: Boolean,
        required: true
    }
},{timestamps:true})

const Department = mongoose.model('department',DepartmentSchema)
module.exports = Department