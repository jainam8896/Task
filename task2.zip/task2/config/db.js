const mongoose = require('mongoose')

const db = mongoose.connect('mongodb://localhost:27017/Reference').then(()=>{
    try {
        console.log('Database Connection Successfully');
    } catch (error) {
        console.log('Database not Connected');
    }
})

module.exports = db