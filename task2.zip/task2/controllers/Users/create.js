const User = require('../../models/User.js')

//Create user
const createUser = async(req,res)=>{
    try {
        const user = await User.create(req.body)
        res.json(user)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {createUser}