const User = require('../../models/User.js')

//Delete User
const deleteuser = async (req,res) => {
    try {
        const { id } = req.params
        const user = await User.findByIdAndDelete(id)
        if (!user) {
            return res.json('User is not found!')
        }
        res.json("User Deleted Successfully")
    } catch (error) {
        res.json(error.message);
    }
}

module.exports = {deleteuser}