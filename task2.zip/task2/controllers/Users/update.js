const User = require('../../models/User.js')

//Update Users
const updateUsers = async(req,res) => {
    try {
        const {id} = req.params;
        const user = await User.findByIdAndUpdate(id,req.body)
        if(!user){
            return res.json({message: `Job id ${id} is Invalid`})
        }
        const updateuser = await Department.findById(id)
        res.json(updateuser)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {updateUsers}