const User = require('../../models/User.js')

//Display users
const getUsers = async (req,res) =>{
    try {
        const user = await User.find({})
        if(!user){
            return res.json('The User is not found!')
        }
        res.json(user)
    } catch (error) {
        res.json(error)
    }
}

//display Department And Job By user Id
const getDeptJob = async(req,res) => {
    try {
        const {id} = req.params
        const user = await User.findById(id).populate([{path: 'department_id',select:'name'},{path: 'job_id',select:'name'}])
        //const user = await User.findById(id).populate('department_id','job_id')
        if(!user){
            return res.json('The User is not found!')
        }
        res.json(user)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {getUsers,getDeptJob}