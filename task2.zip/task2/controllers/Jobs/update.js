const Job = require('../../models/Job.js')

//Update Job
const updateJob = async(req,res) => {
    try {
        const {id} = req.params;
        const job = await Job.findByIdAndUpdate(id,req.body)
        if(!job){
            return res.json({message: `Job id ${id} is Invalid`})
        }
        res.json({message: `Job Updated Successfully`})
        const updateJob = await Department.findById(id)
        res.json(updateJob)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {updateJob}