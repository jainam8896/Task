const Job = require('../../models/Job.js')

//Create Job
const createJob = async(req,res)=>{
    try {
        const job = await Job.create(req.body)
        res.json(job)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {createJob}