const Job = require('../../models/Job.js')

//Display Department
const getJob = async (req,res) =>{
    try {
        const job = await Job.find({})
        if(!job){
            return res.json('The Job is not found!')
        }
        res.json(job)
    } catch (error) {
        res.json(error)
    }
}

//Display Job By Id
const getJobByid = async(req,res)=>{
    try {
        const {id} = req.params
        const job = await Job.findById(id)
        res.json(job)
    } catch (error) {
        res.json(error)        
    }
}

module.exports = {getJob,getJobByid}