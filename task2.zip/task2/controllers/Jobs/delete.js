const Job = require('../../models/Job.js')

//Delete Job
const deleteJob = async (req,res) => {
    try {
        const { id } = req.params
        const job = await Job.findByIdAndDelete(id)
        if (!job) {
            return res.json('The Job is not found!')
        }
        res.json("Job Deleted Successfully")
    } catch (error) {
        res.json(error.message);
    }
}

module.exports = {deleteJob}