const Department = require('../../models/Department.js')

//Update Department
const updatedept = async(req,res) => {
    try {
        const {id} = req.params;
        const dept = await Department.findByIdAndUpdate(id,req.body)
        if(!dept){
            return res.json({message: `Dept id ${id} is Invalid`})
        }
        const updatedept = await Department.findById(id)
        res.json(updatedept)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {updatedept}
