const Department = require('../../models/Department.js')

//Delete Department
const deleteDept = async (req,res) => {
    try {
        const { id } = req.params
        const dept = await Department.findByIdAndDelete(id)
        if (!dept) {
            return res.json('The Department is not found!')
        }
        res.json("Department Deleted Successfully")
    } catch (error) {
        res.json(error.message);
    }
}

module.exports = {deleteDept}