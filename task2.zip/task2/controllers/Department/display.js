const Department = require('../../models/Department.js')

//Display Department
const getDept = async (req,res) =>{
    try {
        const department = await Department.find({})
        if(!department){
            return res.json('The Department is not found!')
        }
        res.json(department)
    } catch (error) {
        res.json(error)
    }
}

//Display Departmentby Id
const getDeptByid = async(req,res)=>{
    try {
        const {id} = req.params
        const dept = await Department.findById(id)
        res.json(dept)
    } catch (error) {
        res.json(error)        
    }
}

module.exports = {getDept,getDeptByid}