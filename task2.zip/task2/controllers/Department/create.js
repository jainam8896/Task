const Department = require('../../models/Department.js')

//Create Department
const createDept = async(req,res)=>{
    try {
        const department = await Department.create(req.body)
        res.json(department)
    } catch (error) {
        res.json(error)
    }
}

module.exports = {createDept}