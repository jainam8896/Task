const express = require('express')
const router = express.Router()
const Job = require('../models/Job.js')
const {createJob} = require('../controllers/Jobs/create.js')
const {getJob,getJobByid} = require('../controllers/Jobs/display.js')
const {updateJob} = require('../controllers/Jobs/update.js')
const {deleteJob} = require('../controllers/Jobs/delete.js')

// Routes
router.post('/api/createjob',createJob)
router.get('/api/getjob',getJob)
router.get('/api/getjob/:id',getJobByid)
router.put('/api/updatejob/:id',updateJob)
router.delete('/api/deletejob/:id',deleteJob)


module.exports = router