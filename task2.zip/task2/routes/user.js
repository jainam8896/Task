const express = require('express')
const router = express.Router()
const User = require('../models/User.js')
const {createUser} = require('../controllers/Users/create.js')
const {getUsers,getDeptJob} = require('../controllers/Users/display.js')
const {deleteuser} = require('../controllers/Users/delete.js')
const {updateUsers} = require('../controllers/Users/update.js')

//Routes
router.post('/api/createuser',createUser)
router.get('/api/getusers',getUsers)
router.get('/api/getdeptjob/:id',getDeptJob)
router.delete('/api/deleteuser/:id',deleteuser)
router.put('/api/updateuser/:id',updateUsers)


module.exports = router