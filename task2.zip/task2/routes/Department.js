const express = require('express')
const router = express.Router()
const Department = require('../models/Department.js')
const {createDept} = require('../controllers/Department/create.js')
const {getDept,getDeptByid} = require('../controllers/Department/display.js')
const {updatedept} = require('../controllers/Department/update.js')
const {deleteDept} = require('../controllers/Department/delete.js')

//Route
router.post('/api/createdept',createDept)
router.get('/api/getdept',getDept)
router.get('/api/getdept/:id',getDeptByid)
router.put('/api/updatedept/:id',updatedept)
router.delete('/api/deletedept/:id',deleteDept)


module.exports = router





