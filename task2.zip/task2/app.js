const express = require('express')
const app = express()
const port = 5050
const deptRoute = require('./routes/Department.js')
const jobRoute = require('./routes/Job.js')
const userRoute = require('./routes/user.js')

//Database
const Database = require('./config/db.js')

//Middleware
app.use(express.json())

//Routes
app.use('/',deptRoute)
app.use('/',jobRoute)
app.use('/',userRoute)


app.listen(port,()=>{
    console.log(`Server Is Running on Port ${port}`);
})